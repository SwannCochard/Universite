package gestionUniversite;

/**
 *
 * @author gaelvarlet
 */
public interface ComposanteFac {
    public double getMoyenne();
    public int getNbEtudiants();
}
