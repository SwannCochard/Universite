package gestionUniversite;

/**
 *
 * @author Swann
 */
public class LancementTest {
    
    public static void main(String[] args) {
        Batch biatch = new Batch();
        biatch.afficherMenuPrincipal();
    }
}
