package gestionUniversite;

/**
 *
 * @author gaelvarlet
 */
public class GroupeEtudiants implements ComposanteFac{

    @Override
    public double getMoyenne() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int getNbEtudiants() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
