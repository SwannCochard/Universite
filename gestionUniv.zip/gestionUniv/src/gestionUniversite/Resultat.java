package gestionUniversite;

/**
 *
 * @author gaelvarlet
 */
public class Resultat {
    
}
