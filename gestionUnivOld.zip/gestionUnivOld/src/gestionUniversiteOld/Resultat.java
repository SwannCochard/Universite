package gestionUniversiteOld;

/**
 *
 * @author Swann
 */
public class Resultat {
    
}
