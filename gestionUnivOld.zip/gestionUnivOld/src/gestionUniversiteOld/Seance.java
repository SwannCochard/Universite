package gestionUniversiteOld;

import java.util.Enumeration;

/**
 *
 * @author Swann
 */
public class Seance {
    private Enumeration type;
    private String codeModule;
    private String jour;
    private int heure;
    private int duree;
    private Salle salle;
}
